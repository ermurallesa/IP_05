﻿using System;

class Circulo
{
    private double radio;

    public Circulo(double radio)
    {
        this.radio = radio;
    }

    private double ObtenerPerimetro()
    {
        return 2 * Math.PI * radio;
    }

    private double ObtenerArea()
    {
        return Math.PI * Math.Pow(radio, 2);
    }

    private double ObtenerVolumen()
    {
        return 0;
    }

    public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
    {
        unPerimetro = ObtenerPerimetro();
        unArea = ObtenerArea();
        unVolumen = ObtenerVolumen();
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el radio del círculo: ");
        double radio = Convert.ToDouble(Console.ReadLine());
        Circulo objCirculo = new Circulo(radio);

        double perimetro = 0, area = 0, volumen = 0;

        objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

        Console.WriteLine($"Perímetro del círculo: {perimetro}");
        Console.WriteLine($"Área del círculo: {area}");
        Console.WriteLine($"Volumen de la esfera: {volumen}");

        Console.ReadKey();
    }
}

