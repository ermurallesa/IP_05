﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, sEdad, sCarrera, sCarne;

        Console.WriteLine("Escribe tu nombre");
        sNombre = Console.ReadLine();
        Console.WriteLine();

        Console.WriteLine("Escribe tu edad");
        sEdad = Console.ReadLine();
        Console.WriteLine();

        Console.WriteLine("Escribe tu carrera");
        sCarrera = Console.ReadLine();
        Console.WriteLine();

        Console.WriteLine("Escribe tu carné");
        sCarne = Console.ReadLine();
        Console.WriteLine();

        Console.Write("Soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera + "." + " Mi número de carné es " + sCarne);


        Console.ReadKey();
    }
}