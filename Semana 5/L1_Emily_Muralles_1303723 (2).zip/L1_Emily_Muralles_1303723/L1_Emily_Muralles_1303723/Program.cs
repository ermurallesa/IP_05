﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola mundo");
        Console.WriteLine("soy " + Nombre);

        /*Cosole.writeline escribe una linea luego de otra, mientras que
         * console.write ecribe todo en la misma linea*/

        Console.Write("Hola Mundo ");
        Console.Write("soy " + Nombre);
        Console.ReadKey();
    }
}