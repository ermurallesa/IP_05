﻿using System;

class Program
{
    static void Main()
    {
        double Compra;
        double descuento = 0.0;

        Console.Write("Ingrese el monto de compra en Q: ");
        string input = Console.ReadLine();

        if (string.IsNullOrEmpty(input))
        {
            Console.WriteLine("Error: Debe ingresar un monto válido.");
            return;
        }

        if (double.TryParse(input, out Compra))
        {
            if (Compra < 400)
            {
                
                descuento = 0.0;
            }
            else
            {
                if (Compra <= 1000)
                {
                    
                    descuento = Compra * 0.07;
                }
                else
                {
                    if (Compra <= 5000)
                    {
                        
                        descuento = Compra * 0.10;
                    }
                    else
                    {
                        if (Compra <= 15000)
                        {
                            
                            descuento = Compra * 0.15;
                        }
                        else
                        {
                            
                            descuento = Compra * 0.25;
                        }
                    }
                }
            }

            Console.Write("¿Tiene un código de descuento? (Ingrese Si o No)");
            string Codigo = Console.ReadLine();

            if (Codigo.ToUpper() == "SI")
            {
                
                descuento += Compra * 0.05;
            }

            double Final = Compra - descuento;
            Console.WriteLine("Monto a pagar final : " + Final);
        }
        else
        {
            Console.WriteLine("Error: Ingrese un monto válido en números.");
        }
    }
}
