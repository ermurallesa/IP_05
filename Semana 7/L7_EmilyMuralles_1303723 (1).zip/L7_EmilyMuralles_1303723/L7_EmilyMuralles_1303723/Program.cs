﻿using System;
using System.ComponentModel;
{

    int numero = 0;

    Console.WriteLine("Ejercicio 1");
    Console.WriteLine();
    Console.WriteLine("Ingrese un número ENTERO");
    Console.WriteLine();

    numero = Convert.ToInt32(Console.ReadLine());

    if (numero > 0)
    {
        Console.WriteLine();
        Console.WriteLine("RESULTADO: El número ingresado es positivo");
    }
    else if (numero < 0)
    {
        Console.WriteLine();
        Console.WriteLine("RESULTADO: El número ingresado es negativo");
    }
    else
    {
        Console.WriteLine();
        Console.WriteLine("RESULTADO: El número es igual a 0");
    }
    Console.ReadKey();




    Console.WriteLine("Ejercicio 2");
    Console.WriteLine();
    Console.WriteLine("Selecciona una opción");
    Console.WriteLine("Días de la semana");
    Console.WriteLine();
    Console.WriteLine("1. lunes");
    Console.WriteLine("2. martes");
    Console.WriteLine("3. miercoles");
    Console.WriteLine("4. jueves");
    Console.WriteLine("5. viernes");
    Console.WriteLine("6. sabado");
    Console.WriteLine("7. domingo");
    string opcion = (Console.ReadLine());

    switch (opcion)
    {
        case "1":
            Console.WriteLine("DÍA: Lunes");
            break;
        case "2":
            Console.WriteLine("DÍA: Martes");
            break;
        case "3":
            Console.WriteLine("DÍA: Miercoles");
            break;
        case "4":
            Console.WriteLine("DÍA: Jueves");
            break;
        case "5":
            Console.WriteLine("DÍA: Viernes");
            break;
        case "6":
            Console.WriteLine("DÍA: Sabado");
            break;
        case "7":
            Console.WriteLine("DÍA: Domingo");
            break;
            default: Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
            break;

    }

}


