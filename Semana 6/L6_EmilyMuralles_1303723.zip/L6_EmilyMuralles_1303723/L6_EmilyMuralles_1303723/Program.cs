﻿using System;
internal class Program
{
    private static void Main(string[] args)
    {
        {
            Console.WriteLine("Ejercicio 1: Operaciones Aritmeticas");

            int numero1 = 0;
            int numero2 = 0;

            int suma = 0;
            int resta = 0;
            int multiplicacion = 0;
            int division = 0;
            int mod = 0;

            Console.WriteLine("Ingresa el primer número");
            numero1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Ingresa el segundo número");
            numero2 = Convert.ToInt32(Console.ReadLine());

            suma = numero1 + numero2;
            multiplicacion = numero1 * numero2;
            division = numero1 / numero2;
            mod = numero1 % numero2;
            resta = numero1 - numero2;


            Console.WriteLine("El resultado de la suma es " + suma);
            Console.WriteLine();
            Console.WriteLine("El resultado de la resta es " + resta);
            Console.WriteLine();
            Console.WriteLine("El resultado de la multiplicación es " + multiplicacion);
            Console.WriteLine();
            Console.WriteLine("El resultado de la división es " + division);
            Console.WriteLine();
            Console.WriteLine("El resultado del modulo es " + mod);
            Console.WriteLine();
            Console.WriteLine("Presione Enter para continuar");
            Console.WriteLine();
            Console.ReadKey();

            Console.WriteLine();
            Console.WriteLine("Ejercicio 2: Operaciones Booleanas");

            Console.WriteLine("El numero 1 es mayor que (>) el número 2: " + (numero1 > numero2));
            Console.WriteLine();
            Console.WriteLine("\"El numero 1 es menor que (<) el número 2: " + (numero1 < numero2));
            Console.WriteLine();
            Console.WriteLine("\"El numero 1 es igual que (=) el número 2: " + (numero1 == numero2));

            Console.WriteLine();
            Console.WriteLine("Presione Enter para continuar");
            Console.WriteLine();
            Console.ReadKey();
        }

        {
            Console.WriteLine("Ejercicio 3: Jerarquía de Operaciones y Formula Cuadrática");
            //Variables para Jerarquía de operaciones//

            double a = 0;
            double b = 0;
            double c = 0;
            double operacion1 = 0;
            double operacion2 = 0;
            double operacion3 = 0;
            double operacion4 = 0;

            //Variables para formula cuadratica//
            double discriminante = Math.Pow(b, 2) - 4 * a * c;
            double solución1 = 0;
            double solución2 = 0;


            Console.WriteLine();

            Console.WriteLine("Ingrese el coeficiente a");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Ingrese el coeficiente b");
            b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Ingrese el coeficiente c");
            c = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            operacion1 = a * b + c;
            operacion2 = a * (b + c);
            operacion3 = a / b + c;
            operacion4 = (3 * a + 2 * b) / Math.Pow(c, 2);

            if (a == 0)
            {
                Console.WriteLine("Error: El coeficiente 'a' debe ser diferente de 0.");
            }
            else if (discriminante < 0)
            {
                Console.WriteLine("Error: El discriminante es negativo. No hay soluciones reales.");
            }
            else
            {

            }

             solución1 = (-b + Math.Sqrt(discriminante)) / (2 * a);
             solución2 = (-b - Math.Sqrt(discriminante)) / (2 * a);

            Console.WriteLine("Resultado de a * b + c:" + operacion1);
            Console.WriteLine();
            Console.WriteLine("Resultado de a * (b + c):" + operacion2);
            Console.WriteLine();
            Console.WriteLine("Resultado de a / (b * c): " + operacion3);
            Console.WriteLine();
            Console.WriteLine("Resultado de 3a + 2b / c^2:" + operacion4);
            Console.WriteLine();

            Console.WriteLine("La solución uno al aplicar la formula cuadrática es: " + solución1);
            Console.WriteLine();
            Console.WriteLine("La solución dos al aplicar la formula cuadrática es: " + solución2);
            Console.WriteLine();
            Console.WriteLine("Presiona Enter para cerrar el programa");
            Console.ReadKey();

        }
    }
}