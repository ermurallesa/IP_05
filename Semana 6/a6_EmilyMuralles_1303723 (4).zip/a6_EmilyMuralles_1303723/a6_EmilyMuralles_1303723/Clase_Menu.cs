﻿Console.WriteLine("Programa de Inventario de Ventas de Cosmeticos por Catalogo");
Console.ReadKey();
Console.WriteLine("Selecciona una opción");
Console.WriteLine("Productos del catalogo");
Console.WriteLine("1. labial");
Console.WriteLine("2. rimel");
Console.WriteLine("3. rubor");
Console.WriteLine("4. sombras");
Console.WriteLine("5. rizador de pestañas");
Console.WriteLine("6. delineador");
string opcion = Console.ReadLine();

switch (opcion)
{
    case "1":
        Console.WriteLine("Seleccionó opcion " + opcion + " labial");
        break;
    case "2":
        Console.WriteLine("Seleccionó opcion " + opcion + " rimel");
        break;
    case "3":
        Console.WriteLine("Seleccionó opcion " + opcion + " rubor");
        break;
    case "4":
        Console.WriteLine("Seleccionó opcion " + opcion + " sombras");
        break;
    case "5":
        Console.WriteLine("Seleccionó opcion" + opcion + "rizador de pestañas");
        break;
    case "6":
        Console.WriteLine("Seleccionó opcion" + opcion + "delineador");
        break;
     
   

}
Console.WriteLine("Seleccionó la opcion " + opcion);
Console.ReadKey();
