﻿using System;

class Program
{
    static void Main()
    {
        int opcion;
        int opcion2;
        int opcion3;

        Console.WriteLine("Programa de Inventario de Ventas de Cosméticos por Catálogo");
        Console.ReadKey();
        Console.WriteLine("El siguiente programa establece un sistema de navegación por el inventario del Catálogo de Ventas de Cosméticos, mostrando cada producto, sus existencias y ventas durante el presente mes.");
        Console.ReadKey();

        do
        {
            Console.WriteLine("Menú Principal");
            Console.WriteLine("Selecciona una Opción");
            Console.WriteLine("1. Productos del catálogo");
            Console.WriteLine("2. Manual de Usuario");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("0. Salir");
            Console.Write("Seleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out opcion))
            {
                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Productos del catálogo");
                        do
                        {
                            Console.WriteLine("Selecciona un producto:");
                            Console.WriteLine("1. Labial");
                            Console.WriteLine("2. Rimel");
                            Console.WriteLine("3. Rubor");
                            Console.WriteLine("4. Sombras");
                            Console.WriteLine("5. Rizador de pestañas");
                            Console.WriteLine("6. Delineador");
                            Console.WriteLine("0. Regresar al menú anterior");
                            Console.Write("Seleccione una opción: ");

                            if (int.TryParse(Console.ReadLine(), out opcion2))
                            {
                                switch (opcion2)
                                {
                                    case 1:
                                        Console.WriteLine("Seleccionó opción " + opcion2 + ": Labial");
                                        do
                                        {
                                            Console.WriteLine("Menú resultados:");
                                            Console.WriteLine("1. Mostrar resultados");
                                            Console.WriteLine("2. Regresar al menú anterior");
                                            Console.WriteLine("3. Regresar al menú principal");
                                            Console.WriteLine("4. Salir");
                                            Console.Write("Seleccione una opción: ");

                                            if (int.TryParse(Console.ReadLine(), out opcion3))
                                            {
                                                switch (opcion3)
                                                {
                                                    case 1:
                                                        Console.WriteLine("Mostrando resultados para Labial.");
                                                        // resultados de Labial
                                                        break;
                                                    case 2:
                                                        Console.WriteLine("Regresando al menú anterior.");
                                                        break;
                                                    case 3:
                                                        Console.WriteLine("Regresando al menú principal.");
                                                        break;
                                                    case 4:
                                                        Console.WriteLine("Saliendo del programa.");
                                                        Environment.Exit(0);
                                                        break;
                                                    default:
                                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                                        break;
                                                }

                                                if (opcion3 == 2 || opcion3 == 3)
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                                            }
                                        } while (true);
                                        break;
                                    case 2:
                                        Console.WriteLine("Seleccionó opción " + opcion2 + ": Rimel");
                                        do
                                        {
                                            Console.WriteLine("Menú resultados:");
                                            Console.WriteLine("1. Mostrar resultados");
                                            Console.WriteLine("2. Regresar al menú anterior");
                                            Console.WriteLine("3. Regresar al menú principal");
                                            Console.WriteLine("4. Salir");
                                            Console.Write("Seleccione una opción: ");

                                            if (int.TryParse(Console.ReadLine(), out opcion3))
                                            {
                                                switch (opcion3)
                                                {
                                                    case 1:
                                                        Console.WriteLine("Mostrando resultados para Rimel.");
                                                        // resultados de Rimel
                                                        break;
                                                    case 2:
                                                        Console.WriteLine("Regresando al menú anterior.");
                                                        break;
                                                    case 3:
                                                        Console.WriteLine("Regresando al menú principal.");
                                                        break;
                                                    case 4:
                                                        Console.WriteLine("Saliendo del programa.");
                                                        Environment.Exit(0);
                                                        break;
                                                    default:
                                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                                        break;
                                                }

                                                if (opcion3 == 2 || opcion3 == 3)
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                                            }
                                        } while (true);
                                        break;
                                        break;
                                    case 3:
                                        Console.WriteLine("Seleccionó opción " + opcion2 + ": Rubor");
                                        do
                                        {
                                            Console.WriteLine("Menú resultados:");
                                            Console.WriteLine("1. Mostrar resultados");
                                            Console.WriteLine("2. Regresar al menú anterior");
                                            Console.WriteLine("3. Regresar al menú principal");
                                            Console.WriteLine("4. Salir");
                                            Console.Write("Seleccione una opción: ");

                                            if (int.TryParse(Console.ReadLine(), out opcion3))
                                            {
                                                switch (opcion3)
                                                {
                                                    case 1:
                                                        Console.WriteLine("Mostrando resultados para Rubor.");
                                                        // resultados de Rubor
                                                        break;
                                                    case 2:
                                                        Console.WriteLine("Regresando al menú anterior.");
                                                        break;
                                                    case 3:
                                                        Console.WriteLine("Regresando al menú principal.");
                                                        break;
                                                    case 4:
                                                        Console.WriteLine("Saliendo del programa.");
                                                        Environment.Exit(0);
                                                        break;
                                                    default:
                                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                                        break;
                                                }

                                                if (opcion3 == 2 || opcion3 == 3)
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                                            }
                                        } while (true);
                                        break;
                                        break;
                                    case 4:
                                        Console.WriteLine("Seleccionó opción " + opcion2 + ": Sombras");
                                        do
                                        {
                                            Console.WriteLine("Menú resultados:");
                                            Console.WriteLine("1. Mostrar resultados");
                                            Console.WriteLine("2. Regresar al menú anterior");
                                            Console.WriteLine("3. Regresar al menú principal");
                                            Console.WriteLine("4. Salir");
                                            Console.Write("Seleccione una opción: ");

                                            if (int.TryParse(Console.ReadLine(), out opcion3))
                                            {
                                                switch (opcion3)
                                                {
                                                    case 1:
                                                        Console.WriteLine("Mostrando resultados para Sombras.");
                                                        // resultados de sombras
                                                        break;
                                                    case 2:
                                                        Console.WriteLine("Regresando al menú anterior.");
                                                        break;
                                                    case 3:
                                                        Console.WriteLine("Regresando al menú principal.");
                                                        break;
                                                    case 4:
                                                        Console.WriteLine("Saliendo del programa.");
                                                        Environment.Exit(0);
                                                        break;
                                                    default:
                                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                                        break;
                                                }

                                                if (opcion3 == 2 || opcion3 == 3)
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                                            }
                                        } while (true);
                                        break;
                                        break;
                                    case 5:
                                        Console.WriteLine("Seleccionó opción " + opcion2 + ": Rizador de pestañas");
                                        do
                                        {
                                            Console.WriteLine("Menú resultados:");
                                            Console.WriteLine("1. Mostrar resultados");
                                            Console.WriteLine("2. Regresar al menú anterior");
                                            Console.WriteLine("3. Regresar al menú principal");
                                            Console.WriteLine("4. Salir");
                                            Console.Write("Seleccione una opción: ");

                                            if (int.TryParse(Console.ReadLine(), out opcion3))
                                            {
                                                switch (opcion3)
                                                {
                                                    case 1:
                                                        Console.WriteLine("Mostrando resultados para Rizador de Pestañas.");
                                                        // resultados de rizador
                                                        break;
                                                    case 2:
                                                        Console.WriteLine("Regresando al menú anterior.");
                                                        break;
                                                    case 3:
                                                        Console.WriteLine("Regresando al menú principal.");
                                                        break;
                                                    case 4:
                                                        Console.WriteLine("Saliendo del programa.");
                                                        Environment.Exit(0);
                                                        break;
                                                    default:
                                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                                        break;
                                                }

                                                if (opcion3 == 2 || opcion3 == 3)
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                                            }
                                        } while (true);
                                        break;
                                        break;
                                    case 6:
                                        Console.WriteLine("Seleccionó opción " + opcion2 + ": Delineador");
                                        do
                                        {
                                            Console.WriteLine("Menú resultados:");
                                            Console.WriteLine("1. Mostrar resultados");
                                            Console.WriteLine("2. Regresar al menú anterior");
                                            Console.WriteLine("3. Regresar al menú principal");
                                            Console.WriteLine("4. Salir");
                                            Console.Write("Seleccione una opción: ");

                                            if (int.TryParse(Console.ReadLine(), out opcion3))
                                            {
                                                switch (opcion3)
                                                {
                                                    case 1:
                                                        Console.WriteLine("Mostrando resultados para Delineador.");
                                                        // resultados de delineador
                                                        break;
                                                    case 2:
                                                        Console.WriteLine("Regresando al menú anterior.");
                                                        break;
                                                    case 3:
                                                        Console.WriteLine("Regresando al menú principal.");
                                                        break;
                                                    case 4:
                                                        Console.WriteLine("Saliendo del programa.");
                                                        Environment.Exit(0);
                                                        break;
                                                    default:
                                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                                        break;
                                                }

                                                if (opcion3 == 2 || opcion3 == 3)
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                                            }
                                        } while (true);
                                        break;
                                        break;
                                    case 0:
                                        Console.WriteLine("Regresando al menú anterior.");
                                        break;
                                    default:
                                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                                        break;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
                            }
                        } while (opcion2 != 0);
                        break;
                    case 2:
                        Console.WriteLine("Manual de Usuario");
                        //Quitar esto




                        Console.WriteLine("Este programa incluye diversos menú de navegacion, dependendiendo de la accion a realizar, se establace lo siguiente. Si selecciona menu principal obtendra todos los servicios incluidos en el proyecto. Si selecciona manual de usuario, se le explicara como usar este prgrama. Si seleeciona creditos le mostrara la información sobre los programadores del proyecto.");
                        Console.WriteLine("Para que usted pueda ver la solucion de la problematica reuqerida, tiene que seleccionar la opción 1 (proceso principal). Al seleccionar eso sera dirigido a un segundo menú con los productos en inventario.");
                        Console.WriteLine("Seleccione una de las 6 opciones enlistadas y se mostraran los resultados del inventario disponible");
                        Console.WriteLine("El proposito de este programa es que el usuario pueda saber cuanto producto se vende por venta personal de los empleados de esta empresa");
                        break;
                    case 3:
                        Console.WriteLine("Créditos");
                        Console.WriteLine("Nombre del Programa: Programa de Inventario de Ventas de Cosméticos por Catálogo");
                        Console.WriteLine("Fecha de Creación: 3 de Octubre de 2023");
                        //Cambiar esto
                        Console.WriteLine("Horas Invertidas en el programa: 5");
                        Console.WriteLine("Programadoras:");
                        Console.WriteLine("1. Emily Rocío Muralles Alvarado");
                        Console.WriteLine("Carné: 1303723");
                        Console.WriteLine("Carrera: Ingeniería Industrial");
                        //Completar estos datos
                        Console.WriteLine("2. Daniela Sofía");
                        Console.WriteLine("Carné: 1296223 ");
                        Console.WriteLine("Carrera: Ingeniería Industrial");
                        break;
                    case 0:
                        Console.WriteLine("Saliendo del programa.");
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Entrada no válida. Por favor, introduzca un número válido.");
            }

            Console.WriteLine();
        } while (opcion != 0);
    }
}

