﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ingrese 3 de las 4 variables del movimiento rectilíneo uniformemente variado:");
        Console.Write("Velocidad Inicial (V0): ");
        double v0 = GetInput();

        Console.Write("Velocidad Final (Vf): ");
        double vf = GetInput();

        Console.Write("Aceleración (a): ");
        double a = GetInput();

        Console.Write("Tiempo (t): ");
        double t = GetInput();

        // Verificar la entrada del usuario
        int variablesIngresadas = CountEnteredVariables(v0, vf, a, t);

        if (variablesIngresadas == 4 || variablesIngresadas == 0)
        {
            Console.WriteLine("Error: Ingrese exactamente 3 de las 4 variables.");
        }
        else
        {
            // Calcular la variable faltante
            if (variablesIngresadas == 1)
            {
                if (v0 == 0) v0 = vf - a * t;
                else if (vf == 0) vf = v0 + a * t;
                else if (a == 0) a = (vf - v0) / t;
                else if (t == 0) t = (vf - v0) / a;

                Console.WriteLine($"Resultado: V0={v0}, Vf={vf}, a={a}, t={t}");
            }
            else
            {
                Console.WriteLine("Error: Ingrese exactamente 3 de las 4 variables.");
            }
        }
    }

    static double GetInput()
    {
        while (true)
        {
            if (double.TryParse(Console.ReadLine(), out double result))
            {
                return result;
            }
            else
            {
                Console.WriteLine("Error: Ingrese un valor numérico válido.");
            }
        }
    }

    static int CountEnteredVariables(params double[] variables)
    {
        int count = 0;
        foreach (var variable in variables)
        {
            if (variable != 0) count++;
        }
        return count;
    }
}
